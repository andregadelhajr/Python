print('A expressão 10 + 20 x 30 é:')
print(10 + 20 * 30)
10 + 20 * 30
print('A expressão 4^2 / 30 é:')
print(4**2 / 30)
4**2 / 30
print('A expressão (9^2 + 2) x 6 - 1 é:')
print((9**2 + 2) * 6 - 1)
(9**2 + 2) * 6 - 1

