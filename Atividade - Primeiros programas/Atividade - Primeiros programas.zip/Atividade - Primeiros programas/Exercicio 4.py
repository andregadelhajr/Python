print('O resultado da expressão 2a x 3b é:')
A = 3
B = 5    
print((2*A) * (3*B))
