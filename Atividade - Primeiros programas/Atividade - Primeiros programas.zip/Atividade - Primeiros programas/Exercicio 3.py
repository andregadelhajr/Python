print('Nome = Renata Domingos Manso de Oliveira Nascimento')
