print('O resultado da expressçao 10 % 3 * 10 ** 2 + 1 - 10 * 4 / 2 é:')
print(10 % 3 * 10 ** 2 + 1 - 10 * 4 / 2)
